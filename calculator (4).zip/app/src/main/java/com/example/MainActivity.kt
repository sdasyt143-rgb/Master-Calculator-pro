package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

data class NoteItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val timestamp: String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
)

class CalculatorEngine(context: Context) {
    private val webView = WebView(context).apply {
        settings.javaScriptEnabled = true
        loadDataWithBaseURL(null, """
            <!DOCTYPE html>
            <html>
            <head>
            <script>
            function calculateResult(expression) {
                try {
                    // Remove all whitespace
                    expression = expression.replace(/\s+/g, '');

                    // Handle percentage calculations dynamically (e.g., num1 operator num2%)
                    if (expression.includes('%')) {
                        expression = expression.replace(/([0-9.]+)([+\-*/])([0-9.]+)%/g, function(match, num1, operator, num2) {
                            let calculatedPercent = (parseFloat(num1) * parseFloat(num2)) / 100;
                            return num1 + operator + calculatedPercent;
                        });
                        
                        // Fallback for standalone percentages
                        expression = expression.replace(/([0-9.]+)%/g, function(match, num) {
                            return parseFloat(num) / 100;
                        });
                    }

                    let result = eval(expression);
                    return String(result);
                } catch (error) {
                    return "Error";
                }
            }
            </script>
            </head>
            <body></body>
            </html>
        """.trimIndent(), "text/html", "UTF-8", null)
    }

    fun evaluate(expression: String, onResult: (String) -> Unit) {
        if (expression.isBlank()) {
            onResult("")
            return
        }
        val jsExpression = expression
            .replace('×', '*')
            .replace('÷', '/')
            .replace('x', '*')
            .replace('X', '*')

        val sanitized = jsExpression
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", "")

        webView.evaluateJavascript("calculateResult('$sanitized');") { value ->
            val cleanValue = value?.removeSurrounding("\"") ?: "Error"
            onResult(cleanValue)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val historyList = remember { mutableStateListOf<String>() }
    val notesList = remember { mutableStateListOf<NoteItem>() }
    
    val tabs = listOf(
        Triple("Calculator", Icons.Default.Calculate, "calculator_tab"),
        Triple("History", Icons.Default.History, "history_tab"),
        Triple("More Tools", Icons.Default.Build, "more_tools_tab"),
        Triple("Note", Icons.Default.Description, "note_tab")
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_navigation")
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        icon = { Icon(tab.second, contentDescription = tab.first) },
                        label = { Text(tab.first) },
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        modifier = Modifier.testTag(tab.third)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> CalculatorScreen(
                    onCalculationFinished = { item ->
                        historyList.add(0, item)
                    },
                    onAddToNote = { calculation ->
                        notesList.add(0, NoteItem(title = "Calculation Result", content = calculation))
                    }
                )
                1 -> HistoryScreen(
                    historyList = historyList,
                    onClearHistory = { historyList.clear() }
                )
                2 -> MoreToolsHubScreen()
                3 -> NoteScreen(
                    notesList = notesList,
                    onAddNote = { title, content ->
                        notesList.add(0, NoteItem(title = title, content = content))
                    },
                    onDeleteNote = { note ->
                        notesList.remove(note)
                    }
                )
            }
        }
    }
}

@Composable
fun HistoryScreen(
    historyList: List<String>,
    onClearHistory: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Calculation History",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (historyList.isNotEmpty()) {
                IconButton(
                    onClick = onClearHistory,
                    modifier = Modifier.testTag("clear_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear History",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        if (historyList.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No history yet.\nCalculations will appear here.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(historyList) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("history_item"),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = item,
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun NoteScreen(
    notesList: List<NoteItem>,
    onAddNote: (String, String) -> Unit,
    onDeleteNote: (NoteItem) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var titleInput by remember { mutableStateOf("") }
    var contentInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { 
                    titleInput = ""
                    contentInput = ""
                    showAddDialog = true 
                },
                modifier = Modifier.testTag("add_note_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Note")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            Text(
                text = "My Notes",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (notesList.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No notes yet.\nTap '+' to create a note or add from Calculator.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(notesList, key = { it.id }) { note ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("note_card"),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = note.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Row {
                                        IconButton(
                                            onClick = {
                                                val sendIntent = Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    putExtra(Intent.EXTRA_SUBJECT, note.title)
                                                    putExtra(Intent.EXTRA_TEXT, "${note.title}\n\n${note.content}\n\nTimestamp: ${note.timestamp}")
                                                    type = "text/plain"
                                                }
                                                val shareIntent = Intent.createChooser(sendIntent, null)
                                                context.startActivity(shareIntent)
                                            },
                                            modifier = Modifier.testTag("share_note_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = "Share Note",
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteNote(note) },
                                            modifier = Modifier.testTag("delete_note_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete Note",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = note.content,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = note.timestamp,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Create New Note") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        label = { Text("Title") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("note_title_input")
                    )
                    OutlinedTextField(
                        value = contentInput,
                        onValueChange = { contentInput = it },
                        label = { Text("Note Content") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("note_content_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (titleInput.isNotBlank() || contentInput.isNotBlank()) {
                            onAddNote(
                                titleInput.ifBlank { "Untitled Note" },
                                contentInput
                            )
                            showAddDialog = false
                        }
                    },
                    modifier = Modifier.testTag("save_note_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showAddDialog = false },
                    modifier = Modifier.testTag("cancel_note_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

// More Tools Hub & Calculators / Converters
sealed class ToolScreen {
    object Hub : ToolScreen()
    object AgeCalculator : ToolScreen()
    object EmiCalculator : ToolScreen()
    object GstCalculator : ToolScreen()
    object DiscountCalculator : ToolScreen()
    object LengthConverter : ToolScreen()
    object AreaConverter : ToolScreen()
    object DataConverter : ToolScreen()
    object TimeConverter : ToolScreen()
}

@Composable
fun MoreToolsHubScreen() {
    var currentScreen by remember { mutableStateOf<ToolScreen>(ToolScreen.Hub) }

    when (currentScreen) {
        is ToolScreen.Hub -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                item {
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Text(
                            text = "More Tools Hub",
                            style = MaterialTheme.typography.headlineLarge,
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Advanced financial calculators & unit conversion utilities",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                item {
                    Text(
                        text = "Financial & Utility Calculators",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        ToolCard(
                            title = "Age Calculator",
                            subtitle = "Calculate exact age (Years, Months, Days)",
                            icon = Icons.Default.Cake,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            iconTint = MaterialTheme.colorScheme.onPrimaryContainer,
                            onClick = { currentScreen = ToolScreen.AgeCalculator },
                            testTag = "tool_age_calculator"
                        )
                        ToolCard(
                            title = "EMI / Loan Calculator",
                            subtitle = "Calculate monthly loan installments and interest",
                            icon = Icons.Default.AccountBalance,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                            iconTint = MaterialTheme.colorScheme.onSecondaryContainer,
                            onClick = { currentScreen = ToolScreen.EmiCalculator },
                            testTag = "tool_emi_calculator"
                        )
                        ToolCard(
                            title = "GST Calculator",
                            subtitle = "Add or remove GST/Tax instantly",
                            icon = Icons.Default.Receipt,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            iconTint = MaterialTheme.colorScheme.onTertiaryContainer,
                            onClick = { currentScreen = ToolScreen.GstCalculator },
                            testTag = "tool_gst_calculator"
                        )
                        ToolCard(
                            title = "Discount Calculator",
                            subtitle = "Calculate savings and final price after discounts",
                            icon = Icons.Default.LocalOffer,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.errorContainer,
                            iconTint = MaterialTheme.colorScheme.onErrorContainer,
                            onClick = { currentScreen = ToolScreen.DiscountCalculator },
                            testTag = "tool_discount_calculator"
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Unit Converters",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        ToolCard(
                            title = "Length Converter",
                            subtitle = "Convert Meters, Kilometers, Feet, Inches, Miles",
                            icon = Icons.Default.Straighten,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            iconTint = MaterialTheme.colorScheme.onPrimaryContainer,
                            onClick = { currentScreen = ToolScreen.LengthConverter },
                            testTag = "tool_length_converter"
                        )
                        ToolCard(
                            title = "Area Converter",
                            subtitle = "Convert Square Meters, Square Feet, Acres, Hectares",
                            icon = Icons.Default.GridOn,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                            iconTint = MaterialTheme.colorScheme.onSecondaryContainer,
                            onClick = { currentScreen = ToolScreen.AreaConverter },
                            testTag = "tool_area_converter"
                        )
                        ToolCard(
                            title = "Data Converter",
                            subtitle = "Convert Bytes, KB, MB, GB, TB",
                            icon = Icons.Default.Storage,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            iconTint = MaterialTheme.colorScheme.onTertiaryContainer,
                            onClick = { currentScreen = ToolScreen.DataConverter },
                            testTag = "tool_data_converter"
                        )
                        ToolCard(
                            title = "Time Converter",
                            subtitle = "Convert Seconds, Minutes, Hours, Days, Years",
                            icon = Icons.Default.Schedule,
                            containerColor = MaterialTheme.colorScheme.surface,
                            iconContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                            onClick = { currentScreen = ToolScreen.TimeConverter },
                            testTag = "tool_time_converter"
                        )
                    }
                }
            }
        }
        is ToolScreen.AgeCalculator -> AgeCalculatorScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.EmiCalculator -> EmiCalculatorScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.GstCalculator -> GstCalculatorScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.DiscountCalculator -> DiscountCalculatorScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.LengthConverter -> LengthConverterScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.AreaConverter -> AreaConverterScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.DataConverter -> DataConverterScreen(onBack = { currentScreen = ToolScreen.Hub })
        is ToolScreen.TimeConverter -> TimeConverterScreen(onBack = { currentScreen = ToolScreen.Hub })
    }
}

@Composable
fun ToolCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    containerColor: androidx.compose.ui.graphics.Color,
    iconContainerColor: androidx.compose.ui.graphics.Color,
    iconTint: androidx.compose.ui.graphics.Color,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = iconContainerColor,
                modifier = Modifier.size(52.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconTint,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun AgeCalculatorScreen(onBack: () -> Unit) {
    var yearInput by remember { mutableStateOf("") }
    var monthInput by remember { mutableStateOf("") }
    var dayInput by remember { mutableStateOf("") }
    var ageResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Age Calculator",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Enter Date of Birth", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = dayInput,
                        onValueChange = { dayInput = it },
                        label = { Text("Day") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_day")
                    )
                    OutlinedTextField(
                        value = monthInput,
                        onValueChange = { monthInput = it },
                        label = { Text("Month") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f).testTag("input_month")
                    )
                    OutlinedTextField(
                        value = yearInput,
                        onValueChange = { yearInput = it },
                        label = { Text("Year") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.2f).testTag("input_year")
                    )
                }
                Button(
                    onClick = {
                        val d = dayInput.toIntOrNull()
                        val m = monthInput.toIntOrNull()
                        val y = yearInput.toIntOrNull()
                        if (d != null && m != null && y != null) {
                            val dob = Calendar.getInstance().apply { set(y, m - 1, d) }
                            val today = Calendar.getInstance()
                            if (dob.after(today)) {
                                ageResult = "Birth date cannot be in the future."
                            } else {
                                var years = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
                                var months = today.get(Calendar.MONTH) - dob.get(Calendar.MONTH)
                                var days = today.get(Calendar.DAY_OF_MONTH) - dob.get(Calendar.DAY_OF_MONTH)
                                if (days < 0) {
                                    months--
                                    days += today.getActualMaximum(Calendar.DAY_OF_MONTH)
                                }
                                if (months < 0) {
                                    years--
                                    months += 12
                                }
                                ageResult = "$years Years, $months Months, $days Days old"
                            }
                        } else {
                            ageResult = "Please enter valid date values."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("calculate_age_btn")
                ) {
                    Text("Calculate Age")
                }
            }
        }

        if (ageResult != null) {
            Spacer(modifier = Modifier.height(24.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Result", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = ageResult!!,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("age_result_text")
                    )
                }
            }
        }
    }
}

@Composable
fun EmiCalculatorScreen(onBack: () -> Unit) {
    var principalInput by remember { mutableStateOf("") }
    var rateInput by remember { mutableStateOf("") }
    var tenureInput by remember { mutableStateOf("") }
    var emiResult by remember { mutableStateOf<String?>(null) }
    var totalInterestResult by remember { mutableStateOf<String?>(null) }
    var totalPaymentResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "EMI / Loan Calculator",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = principalInput,
                    onValueChange = { principalInput = it },
                    label = { Text("Loan Amount ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_principal")
                )
                OutlinedTextField(
                    value = rateInput,
                    onValueChange = { rateInput = it },
                    label = { Text("Annual Interest Rate (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_rate")
                )
                OutlinedTextField(
                    value = tenureInput,
                    onValueChange = { tenureInput = it },
                    label = { Text("Loan Tenure (Years)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_tenure")
                )
                Button(
                    onClick = {
                        val p = principalInput.toDoubleOrNull()
                        val annualRate = rateInput.toDoubleOrNull()
                        val years = tenureInput.toDoubleOrNull()
                        if (p != null && annualRate != null && years != null && p > 0 && annualRate >= 0 && years > 0) {
                            val r = annualRate / 12 / 100
                            val n = years * 12
                            val emi = if (r == 0.0) p / n else (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1)
                            val totalPay = emi * n
                            val totalInt = totalPay - p
                            emiResult = String.format(Locale.getDefault(), "%.2f", emi)
                            totalInterestResult = String.format(Locale.getDefault(), "%.2f", totalInt)
                            totalPaymentResult = String.format(Locale.getDefault(), "%.2f", totalPay)
                        } else {
                            emiResult = "Error"
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("calculate_emi_btn")
                ) {
                    Text("Calculate EMI")
                }
            }
        }

        if (emiResult != null && emiResult != "Error") {
            Spacer(modifier = Modifier.height(24.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Loan Summary", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                    Text("Monthly EMI: $$emiResult", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.testTag("emi_result"))
                    Text("Total Interest: $$totalInterestResult", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Total Payment: $$totalPaymentResult", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
    }
}

@Composable
fun GstCalculatorScreen(onBack: () -> Unit) {
    var amountInput by remember { mutableStateOf("") }
    var gstRateInput by remember { mutableStateOf("18") }
    var isAddMode by remember { mutableStateOf(true) }
    var netResult by remember { mutableStateOf<String?>(null) }
    var gstAmountResult by remember { mutableStateOf<String?>(null) }
    var totalResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "GST Calculator",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { isAddMode = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAddMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text("Add GST", color = if (isAddMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                    }
                    Button(
                        onClick = { isAddMode = false },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isAddMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text("Remove GST", color = if (!isAddMode) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface)
                    }
                }
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_amount")
                )
                OutlinedTextField(
                    value = gstRateInput,
                    onValueChange = { gstRateInput = it },
                    label = { Text("GST Rate (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_gst_rate")
                )
                Button(
                    onClick = {
                        val amt = amountInput.toDoubleOrNull()
                        val rate = gstRateInput.toDoubleOrNull()
                        if (amt != null && rate != null && amt >= 0 && rate >= 0) {
                            if (isAddMode) {
                                val gst = amt * (rate / 100.0)
                                val total = amt + gst
                                netResult = String.format(Locale.getDefault(), "%.2f", amt)
                                gstAmountResult = String.format(Locale.getDefault(), "%.2f", gst)
                                totalResult = String.format(Locale.getDefault(), "%.2f", total)
                            } else {
                                val net = amt / (1.0 + (rate / 100.0))
                                val gst = amt - net
                                netResult = String.format(Locale.getDefault(), "%.2f", net)
                                gstAmountResult = String.format(Locale.getDefault(), "%.2f", gst)
                                totalResult = String.format(Locale.getDefault(), "%.2f", amt)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("calculate_gst_btn")
                ) {
                    Text("Calculate GST")
                }
            }
        }

        if (totalResult != null) {
            Spacer(modifier = Modifier.height(24.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("GST Calculation Summary", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                    Text("Net Amount: $$netResult", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("GST Amount: $$gstAmountResult", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Total Amount: $$totalResult", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.testTag("gst_total_result"))
                }
            }
        }
    }
}

@Composable
fun DiscountCalculatorScreen(onBack: () -> Unit) {
    var priceInput by remember { mutableStateOf("") }
    var discountInput by remember { mutableStateOf("") }
    var savedResult by remember { mutableStateOf<String?>(null) }
    var finalResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Discount Calculator",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = { Text("Original Price ($)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_price")
                )
                OutlinedTextField(
                    value = discountInput,
                    onValueChange = { discountInput = it },
                    label = { Text("Discount (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_discount")
                )
                Button(
                    onClick = {
                        val price = priceInput.toDoubleOrNull()
                        val disc = discountInput.toDoubleOrNull()
                        if (price != null && disc != null && price >= 0 && disc >= 0) {
                            val savings = price * (disc / 100.0)
                            val finalPrice = price - savings
                            savedResult = String.format(Locale.getDefault(), "%.2f", savings)
                            finalResult = String.format(Locale.getDefault(), "%.2f", finalPrice)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("calculate_discount_btn")
                ) {
                    Text("Calculate Discount")
                }
            }
        }

        if (finalResult != null) {
            Spacer(modifier = Modifier.height(24.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Discount Summary", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                    Text("You Save: $$savedResult", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Final Price: $$finalResult", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.testTag("discount_final_result"))
                }
            }
        }
    }
}

@Composable
fun GenericConverterScreen(
    title: String,
    units: List<String>,
    convert: (Double, String, String) -> Double,
    onBack: () -> Unit
) {
    var inputVal by remember { mutableStateOf("") }
    var fromUnit by remember { mutableStateOf(units.first()) }
    var toUnit by remember { mutableStateOf(units.getOrNull(1) ?: units.first()) }
    var resultVal by remember { mutableStateOf<String?>(null) }
    var expandedFrom by remember { mutableStateOf(false) }
    var expandedTo by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("back_button")) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = inputVal,
                    onValueChange = { inputVal = it },
                    label = { Text("Value to Convert") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("converter_input")
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(onClick = { expandedFrom = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("From: $fromUnit")
                        }
                        DropdownMenu(expanded = expandedFrom, onDismissRequest = { expandedFrom = false }) {
                            units.forEach { unit ->
                                DropdownMenuItem(
                                    text = { Text(unit) },
                                    onClick = {
                                        fromUnit = unit
                                        expandedFrom = false
                                    }
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(onClick = { expandedTo = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("To: $toUnit")
                        }
                        DropdownMenu(expanded = expandedTo, onDismissRequest = { expandedTo = false }) {
                            units.forEach { unit ->
                                DropdownMenuItem(
                                    text = { Text(unit) },
                                    onClick = {
                                        toUnit = unit
                                        expandedTo = false
                                    }
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        val v = inputVal.toDoubleOrNull()
                        if (v != null) {
                            val res = convert(v, fromUnit, toUnit)
                            resultVal = String.format(Locale.getDefault(), "%.4f", res)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("convert_btn")
                ) {
                    Text("Convert")
                }
            }
        }

        if (resultVal != null) {
            Spacer(modifier = Modifier.height(24.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Converted Result", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "$resultVal $toUnit",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("converter_result")
                    )
                }
            }
        }
    }
}

@Composable
fun LengthConverterScreen(onBack: () -> Unit) {
    val units = listOf("Meters", "Kilometers", "Feet", "Inches", "Miles")
    val factors = mapOf("Meters" to 1.0, "Kilometers" to 1000.0, "Feet" to 0.3048, "Inches" to 0.0254, "Miles" to 1609.344)
    GenericConverterScreen(
        title = "Length Converter",
        units = units,
        convert = { value, from, to ->
            val inMeters = value * (factors[from] ?: 1.0)
            inMeters / (factors[to] ?: 1.0)
        },
        onBack = onBack
    )
}

@Composable
fun AreaConverterScreen(onBack: () -> Unit) {
    val units = listOf("Square Meters", "Square Feet", "Acres", "Hectares")
    val factors = mapOf("Square Meters" to 1.0, "Square Feet" to 0.092903, "Acres" to 4046.86, "Hectares" to 10000.0)
    GenericConverterScreen(
        title = "Area Converter",
        units = units,
        convert = { value, from, to ->
            val inSqM = value * (factors[from] ?: 1.0)
            inSqM / (factors[to] ?: 1.0)
        },
        onBack = onBack
    )
}

@Composable
fun DataConverterScreen(onBack: () -> Unit) {
    val units = listOf("Bytes", "KB", "MB", "GB", "TB")
    val factors = mapOf("Bytes" to 1.0, "KB" to 1024.0, "MB" to 1048576.0, "GB" to 1073741824.0, "TB" to 1099511627776.0)
    GenericConverterScreen(
        title = "Data Converter",
        units = units,
        convert = { value, from, to ->
            val inBytes = value * (factors[from] ?: 1.0)
            inBytes / (factors[to] ?: 1.0)
        },
        onBack = onBack
    )
}

@Composable
fun TimeConverterScreen(onBack: () -> Unit) {
    val units = listOf("Seconds", "Minutes", "Hours", "Days", "Years")
    val factors = mapOf("Seconds" to 1.0, "Minutes" to 60.0, "Hours" to 3600.0, "Days" to 86400.0, "Years" to 31536000.0)
    GenericConverterScreen(
        title = "Time Converter",
        units = units,
        convert = { value, from, to ->
            val inSecs = value * (factors[from] ?: 1.0)
            inSecs / (factors[to] ?: 1.0)
        },
        onBack = onBack
    )
}

@Composable
fun CalculatorScreen(
    modifier: Modifier = Modifier,
    onCalculationFinished: (String) -> Unit = {},
    onAddToNote: (String) -> Unit = {}
) {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val context = LocalContext.current
    val calculatorEngine = remember { CalculatorEngine(context) }

    fun onButtonClick(value: String) {
        val operators = listOf("+", "-", "×", "÷", "*", "/")
        when (value) {
            "C" -> {
                expression = ""
                result = ""
            }
            "⌫" -> {
                if (expression.isNotEmpty()) {
                    expression = expression.dropLast(1)
                }
            }
            "=" -> {
                if (expression.isNotEmpty()) {
                    calculatorEngine.evaluate(expression) { evaluated ->
                        result = evaluated
                        if (evaluated != "Error") {
                            onCalculationFinished("$expression = $evaluated")
                        }
                    }
                }
            }
            in operators -> {
                result = ""
                if (expression.isNotEmpty()) {
                    val lastChar = expression.takeLast(1)
                    if (lastChar in operators) {
                        expression = expression.dropLast(1) + value
                    } else {
                        expression += value
                    }
                } else if (value == "-") {
                    expression += value
                }
            }
            else -> {
                result = ""
                expression += value
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(
                text = expression.ifEmpty { "0" },
                style = MaterialTheme.typography.headlineLarge.copy(fontSize = 40.sp),
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.End,
                maxLines = 2,
                modifier = Modifier.testTag("expression_display")
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (result.isNotEmpty() && result != "Error") {
                    FilledTonalButton(
                        onClick = { onAddToNote("$expression = $result") },
                        modifier = Modifier.testTag("add_to_note_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NoteAdd,
                            contentDescription = "Add to Note",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add to Note")
                    }
                } else {
                    Spacer(modifier = Modifier.width(1.dp))
                }

                if (result.isNotEmpty()) {
                    Text(
                        text = "= $result",
                        style = MaterialTheme.typography.headlineMedium.copy(fontSize = 32.sp),
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.End,
                        modifier = Modifier.testTag("result_display")
                    )
                }
            }
        }

        // Keypad Grid
        val buttons = listOf(
            listOf("C", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("00", "0", ".", "=")
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            buttons.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    row.forEach { label ->
                        val isOperator = label in listOf("÷", "×", "-", "+", "=")
                        val isSpecial = label in listOf("C", "⌫", "%")
                        
                        Button(
                            onClick = { onButtonClick(label) },
                            modifier = Modifier
                                .weight(1f)
                                .height(72.dp)
                                .testTag("btn_$label"),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when {
                                    label == "=" -> MaterialTheme.colorScheme.primary
                                    isOperator -> MaterialTheme.colorScheme.primaryContainer
                                    isSpecial -> MaterialTheme.colorScheme.secondaryContainer
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                contentColor = when {
                                    label == "=" -> MaterialTheme.colorScheme.onPrimary
                                    isOperator -> MaterialTheme.colorScheme.onPrimaryContainer
                                    isSpecial -> MaterialTheme.colorScheme.onSecondaryContainer
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        ) {
                            if (label == "⌫") {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                                    contentDescription = "Backspace",
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Text(
                                    text = label,
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun CalculatorPreview() {
    MyApplicationTheme {
        MainScreen()
    }
}
